﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DownloadPolicyXML;
using Microsoft.VisualStudio.TestTools.UITesting;
 using  Microsoft.Office.Interop;

namespace MainApp
{
    class Program
    {
        static void Main(string[] args)
        {
         //   Playback.Initialize();
            BrighthousePolicyDownload policy = new BrighthousePolicyDownload();
            policy.BrighthousePolicyDownload_method();
        //    Playback.Cleanup();
        }

       public List<string> fetchPolicyNo_FromInput()
        {
            List<string> policies;
            
            Microsoft.Office.Interop.Excel.Worksheet xlWorkSheet ;
            Microsoft.Office.Interop.Excel.Range range;
            xlWorkSheet.Pa
            try
            {
               
            }
            catch
            {

            }
            
         
            return policies;
        }
    }
}
